import { Modal} from "../components/modal.vue";

export default (app) => {
  app.component("Modal", Modal);

};
